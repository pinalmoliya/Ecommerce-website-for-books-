<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ebookhub";

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define upload directory and create it if it doesn't exist
$uploadDir = "uploads/";
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $price = $_POST['price'];
    $file = $_FILES['file'];

    $fileName = basename($file['name']);
    $targetPath = $uploadDir . $fileName;

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        $sql = "INSERT INTO books (title, author, price, image) VALUES ('$title', '$author', '$price', '$fileName')";
        if ($conn->query($sql) === TRUE) {
            $message = "Book uploaded successfully!";
        } else {
            $message = "Database error: " . $conn->error;
        }
    } else {
        $message = "Error uploading file.";
    }
}

// Fetch books for display
$books = $conn->query("SELECT * FROM books_for_sale ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>EBookHub | Digital Book Marketplace</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    :root {
        --primary-color: #4a90e2;
        --secondary-color: #50c878;
        --bg-color: #f4f4f9;
    }
    body {
        font-family: Arial, sans-serif;
        background-color: var(--bg-color);
        margin: 0;
        padding: 0;
    }
    header {
        background: var(--primary-color);
        color: white;
        padding: 15px;
        text-align: center;
    }
    .container {
        width: 90%;
        margin: auto;
        overflow: hidden;
    }
    form {
        background: white;
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 8px;
    }
    form input, form select {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        transition: all 0.3s ease, box-shadow 0.3s ease;
    }
    form input:focus, form select:focus {
        box-shadow: 0 0 10px var(--secondary-color);
        border-color: var(--secondary-color);
    }
    form button {
        background: var(--secondary-color);
        color: white;
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 5px;
    }
    form button:hover {
        background: #45b16d;
    }
    .message {
        text-align: center;
        background: #dff0d8;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 5px;
        transition: opacity 0.5s ease, transform 0.5s ease;
    }
    /* Carousel Styles */
    .carousel {
        position: relative;
        overflow: hidden;
        margin: 20px 0;
    }
    .carousel-track {
        display: flex;
        transition: transform 0.5s ease;
    }
    .book-slide {
        min-width: 200px;
        margin-right: 30px;
        background: white;
        padding: 10px;
        border-radius: 10px;
        transition: transform 0.4s ease, box-shadow 0.4s ease;
    }
    .book-slide img {
        width: 100%;
        height: 250px;
        object-fit: cover;
        border-radius: 5px;
        transition: transform 0.4s ease;
    }
    .book-slide:hover img {
        transform: scale(1.05);
    }
    .carousel-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: var(--primary-color);
        color: white;
        border: none;
        padding: 10px;
        cursor: pointer;
        border-radius: 50%;
        z-index: 2;
    }
    .carousel-btn.prev {
        left: 10px;
    }
    .carousel-btn.next {
        right: 10px;
    }
</style>
</head>
<body>

<header>
    <h1>📚 EBookHub - Digital Book Marketplace</h1>
</header>

<div class="container">
    <?php if (isset($message)) { ?>
        <div class="message"><?= $message ?></div>
    <?php } ?>

    <form action="" method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Book Title" required>
        <input type="text" name="author" placeholder="Author" required>
        <input type="number" name="price" placeholder="Price" required>
        <input type="file" name="file" accept="image/*" required>
        <button type="submit">Upload Book</button>
    </form>

    <!-- Carousel -->
    <div class="carousel">
        <button class="carousel-btn prev" onclick="prevSlide()">&#10094;</button>
        <div class="carousel-track" id="carouselTrack">
            <?php while ($book = $books->fetch_assoc()) { ?>
                <div class="book-slide">
                    <img src="uploads/<?= $book['image'] ?>" alt="<?= $book['title'] ?>">
                    <h3><?= $book['title'] ?></h3>
                    <p>by <?= $book['author'] ?></p>
                    <p><strong>₹<?= $book['price'] ?></strong></p>
                </div>
            <?php } ?>
        </div>
        <button class="carousel-btn next" onclick="nextSlide()">&#10095;</button>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const track = document.getElementById("carouselTrack");
    const slides = document.querySelectorAll(".book-slide");
    const slideWidth = slides[0]?.offsetWidth + 30 || 0; // margin included
    let index = 0;

    function updateCarousel() {
        track.style.transform = `translateX(${-index * slideWidth}px)`;
    }

    window.nextSlide = function () {
        index = (index + 1) % slides.length;
        updateCarousel();
    };

    window.prevSlide = function () {
        index = (index - 1 + slides.length) % slides.length;
        updateCarousel();
    };

    // Auto-slide
    let autoSlide = setInterval(nextSlide, 5000);

    // Pause on hover
    track.addEventListener("mouseenter", () => clearInterval(autoSlide));
    track.addEventListener("mouseleave", () => {
        autoSlide = setInterval(nextSlide, 5000);
    });

    // Auto-hide messages
    const message = document.querySelector(".message");
    if (message) {
        setTimeout(() => {
            message.style.opacity = "0";
            message.style.transform = "translateY(-20px)";
        }, 3000);
    }
});
</script>

</body>
</html>
