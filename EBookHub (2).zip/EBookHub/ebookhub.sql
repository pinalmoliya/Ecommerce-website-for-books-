CREATE DATABASE IF NOT EXISTS ebookhub;
USE ebookhub;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE `books_for_sale` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `condition_status` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `books_for_sale` (`id`, `title`, `author`, `condition_status`, `price`, `image`, `created_at`) VALUES
(2, 'randhir', 'pinal', 'new', 266.00, '1753506786_logo.png', '2025-07-26 05:13:06'),
(3, 'miss word', 'pinal', 'new', 266.00, '1753516863_i1.jpg', '2025-07-26 08:01:03');



CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `created_at`) VALUES
(1, 'moliya pinal', 'pinalmoliya24@gmail.com', '$2y$10$CTT/6qQvx/zGG9XXqCNE/umQBj/Ep3o704x0G5./tcdsiyANhNIMm', '2025-07-26 08:21:15');


ALTER TABLE `books_for_sale`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);


ALTER TABLE `books_for_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;


ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;


