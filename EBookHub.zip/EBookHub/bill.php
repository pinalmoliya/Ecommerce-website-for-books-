<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ebookhub";

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$book = null;
if (isset($_GET['buy_id'])) {
    $bookId = intval($_GET['buy_id']);
    
    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT title, author, condition_status, price, image FROM books_for_sale WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $bookId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $book = $result->fetch_assoc();
            // Optional: You might want to delete the book from the database after purchase
            // For now, we'll just display the bill.
            // $deleteStmt = $conn->prepare("DELETE FROM books_for_sale WHERE id = ?");
            // if ($deleteStmt) {
            //     $deleteStmt->bind_param("i", $bookId);
            //     $deleteStmt->execute();
            //     $deleteStmt->close();
            // }
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Bill - EBookHub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* CSS Custom Properties (Theme Variables) - Unified with Home, Buy/Sell, Login, Signup */
        :root {
            --primary-color: #3a7bd5;
            --secondary-color: #00d2ff;
            --background-start-color: #f0f4f8; /* For gradient background */
            --background-end-color: #e2e8f0; /* For gradient background */
            --surface-color: rgba(255, 255, 255, 0.9); /* Slightly more opaque glass */
            --text-color: #2c3e50;
            --heading-color: #1a202c; /* Darker heading */
            --shadow-light: rgba(0, 0, 0, 0.08);
            --shadow-medium: rgba(0, 0, 0, 0.15);
            --border-light: rgba(255, 255, 255, 0.3); /* For glass effect borders */
            --success-color: #28a745;
            --error-color: #dc3545;
        }

        /* General Reset & Body Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-start-color), var(--background-end-color));
            background-size: 200% 200%;
            animation: gradientBackground 15s ease infinite;
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center; /* Center content horizontally */
            padding: 20px 0; /* Add vertical padding */
        }

        /* Header & Navigation - Consistent with Home, Login, Signup */
        header {
            width: 100%;
            max-width: 1200px; /* Aligned with main content max-width */
            background: var(--surface-color);
            padding: 1rem 2rem;
            text-align: center;
            box-shadow: 0 4px 12px var(--shadow-light);
            position: sticky; /* Makes it stick to the top */
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(8px);
            border-bottom: 1px solid var(--border-light);
            animation: fadeInDown 0.8s ease-out;
            border-radius: 0 0 15px 15px; /* Rounded bottom corners */
        }

        header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            position: relative;
            display: inline-block;
            animation: pulsateTitle 2s infinite alternate;
        }
        
        header h1::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -5px;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 2px;
            transform: scaleX(0);
            transform-origin: center;
            animation: lineExpand 2s infinite alternate;
        }

        nav {
            margin-top: 0.8rem;
            display: flex;
            justify-content: center;
        }

        nav a {
            margin: 0 18px;
            color: var(--text-color);
            text-decoration: none;
            font-weight: 600;
            padding: 10px 15px;
            position: relative;
            transition: color 0.3s ease, transform 0.3s ease;
            overflow: hidden;
            border-radius: 5px;
        }

        nav a::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, rgba(58, 123, 213, 0.1), rgba(0, 210, 255, 0.1));
            transition: left 0.3s ease-out;
            z-index: -1;
            border-radius: 5px;
        }

        nav a:hover::before {
            left: 0;
        }

        nav a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 3px;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 2px;
            transition: width 0.4s ease-in-out;
        }

        nav a:hover::after,
        nav a.active::after {
            width: 100%;
        }

        nav a:hover,
        nav a.active {
            color: var(--primary-color);
            transform: translateY(-2px);
        }

        /* Bill Container */
        .bill-container {
            max-width: 650px; /* Slightly wider for better content display */
            margin: 60px auto; /* More space from header */
            background: var(--surface-color); /* Glassmorphism background */
            padding: 3rem 3.5rem; /* Increased padding */
            border-radius: 25px; /* More rounded corners */
            box-shadow: 0 20px 50px var(--shadow-medium); /* Stronger shadow */
            animation: slideInUp 1s ease-out forwards; /* Clearer animation */
            opacity: 0; /* Start hidden for animation */
            border: 1px solid var(--border-light); /* Glass border */
            backdrop-filter: blur(5px); /* Glass blur effect */
            position: relative;
            overflow: hidden; /* For pseudo-elements */
        }

        .bill-container::before,
        .bill-container::after {
            content: '';
            position: absolute;
            background: linear-gradient(45deg, rgba(58, 123, 213, 0.1), rgba(0, 210, 255, 0.1));
            border-radius: 50%;
            opacity: 0.6;
            filter: blur(20px);
            z-index: -1;
        }

        .bill-container::before {
            width: 150px;
            height: 150px;
            top: -50px;
            left: -50px;
            animation: floatBubble 6s ease-in-out infinite alternate;
        }

        .bill-container::after {
            width: 200px;
            height: 200px;
            bottom: -80px;
            right: -80px;
            animation: floatBubble 8s ease-in-out infinite alternate reverse;
        }

        .bill-header {
            text-align: center;
            margin-bottom: 35px; /* More space */
        }

        .bill-header h2 {
            font-size: 2.8rem; /* Larger heading */
            color: var(--heading-color); /* Consistent heading color */
            font-weight: 700;
            position: relative;
            display: inline-block;
        }

        .bill-header h2::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 2px;
            animation: lineDraw 1s ease-out forwards;
        }

        .success-msg {
            text-align: center;
            font-size: 1.25rem; /* Slightly larger */
            color: var(--success-color); /* Green from variables */
            margin-bottom: 35px; /* Consistent spacing */
            font-weight: 600;
            background-color: #e6ffe6; /* Lighter success background */
            border: 1px solid var(--success-color);
            padding: 15px 20px;
            border-radius: 10px;
            animation: fadeInMessage 0.8s ease forwards;
            opacity: 0;
            display: flex; /* For icon alignment */
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .success-msg i {
            font-size: 1.5rem; /* Larger checkmark */
        }

        .bill-detail {
            border-top: 2px dashed rgba(0, 0, 0, 0.1); /* Dotted separator */
            border-bottom: 2px dashed rgba(0, 0, 0, 0.1);
            padding: 25px 0; /* Padding for details */
            margin-bottom: 35px; /* Space after details */
        }

        .bill-detail p {
            margin: 15px 0; /* More spacing for readability */
            font-size: 1.15rem; /* Slightly larger font */
            display: flex; /* For alignment of strong tag */
            justify-content: space-between; /* Pushes value to right */
            align-items: center;
        }

        .bill-detail p strong {
            color: var(--text-color);
            font-weight: 600;
            flex-shrink: 0; /* Prevent label from shrinking */
        }
        .bill-detail p span { /* For the values */
            font-weight: 400;
            text-align: right;
            color: #555;
        }

        /* Specific styling for price */
        .bill-detail p.price-row {
            font-size: 1.35rem; /* Highlight price */
            font-weight: 700;
            color: var(--primary-color);
            margin-top: 25px; /* More space for price */
        }
        .bill-detail p.price-row span {
            color: var(--primary-color);
            font-size: 1.5rem;
        }


        .back-btn {
            text-align: center;
            margin-top: 40px; /* More space */
        }

        .back-btn a {
            text-decoration: none;
            color: var(--white);
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color)); /* Consistent primary gradient */
            padding: 16px 35px; /* Larger button */
            border-radius: 15px; /* More rounded */
            font-weight: 700;
            display: inline-block;
            transition: all 0.4s ease;
            box-shadow: 0 10px 25px rgba(58, 123, 213, 0.3); /* Stronger shadow */
            letter-spacing: 0.5px;
            text-transform: uppercase;
            position: relative;
            overflow: hidden;
        }

        .back-btn a::before { /* Shine effect for button */
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: left 0.5s ease-out;
            z-index: 1;
        }

        .back-btn a:hover::before {
            left: 100%;
        }

        .back-btn a:hover {
            background: linear-gradient(45deg, var(--secondary-color), var(--primary-color)); /* Reverse gradient on hover */
            transform: translateY(-5px); /* More pronounced lift */
            box-shadow: 0 15px 35px rgba(0, 210, 255, 0.4);
        }
        .back-btn a i {
            margin-right: 8px; /* Space for icon */
        }
        
        .not-found-msg {
            text-align: center;
            font-size: 1.3rem;
            color: var(--error-color);
            margin-bottom: 30px;
            font-weight: 600;
        }


        /* Keyframe Animations */
        @keyframes gradientBackground {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulsateTitle {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
        }

        @keyframes lineExpand {
            0% { width: 0; }
            50% { width: 100%; }
            100% { width: 0; }
        }

        @keyframes lineDraw {
            from { width: 0; }
            to { width: 80px; }
        }

        @keyframes fadeInMessage {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes floatBubble {
            0% { transform: translate(0, 0) rotate(0deg); }
            25% { transform: translate(20px, -20px) rotate(10deg); }
            50% { transform: translate(0, 0) rotate(0deg); }
            75% { transform: translate(-20px, 20px) rotate(-10deg); }
            100% { transform: translate(0, 0) rotate(0deg); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            header {
                padding: 1rem;
                border-radius: 0 0 10px 10px;
            }
            header h1 {
                font-size: 2.2rem;
            }
            nav {
                flex-wrap: wrap;
                margin-top: 0.5rem;
            }
            nav a {
                margin: 5px 8px;
                padding: 8px 12px;
                font-size: 0.9rem;
            }
            .bill-container {
                padding: 2rem 2rem;
                margin: 40px 15px;
            }
            .bill-header h2 {
                font-size: 2.2rem;
            }
            .bill-header h2::after {
                width: 60px;
            }
            .success-msg, .not-found-msg {
                font-size: 1.1rem;
                padding: 12px 15px;
            }
            .bill-detail p {
                font-size: 1rem;
                margin: 10px 0;
            }
            .bill-detail p.price-row {
                font-size: 1.2rem;
            }
            .bill-detail p.price-row span {
                font-size: 1.3rem;
            }
            .back-btn a {
                padding: 12px 25px;
                font-size: 0.95rem;
            }
        }

        @media (max-width: 480px) {
            header h1 {
                font-size: 1.8rem;
            }
            nav a {
                flex-basis: 45%;
                margin: 5px;
                font-size: 0.8rem;
                padding: 6px 8px;
            }
            .bill-container {
                padding: 1.5rem 1.5rem;
                margin: 30px 10px;
                border-radius: 15px;
            }
            .bill-container::before,
            .bill-container::after {
                width: 100px;
                height: 100px;
                filter: blur(15px);
            }
            .bill-header h2 {
                font-size: 1.8rem;
                margin-bottom: 25px;
            }
            .bill-header h2::after {
                width: 40px;
            }
            .success-msg, .not-found-msg {
                font-size: 1rem;
                padding: 10px 12px;
            }
            .success-msg i {
                font-size: 1.2rem;
            }
            .bill-detail p {
                font-size: 0.95rem;
                margin: 8px 0;
            }
            .bill-detail p.price-row {
                font-size: 1.1rem;
            }
            .bill-detail p.price-row span {
                font-size: 1.2rem;
            }
            .back-btn a {
                padding: 10px 20px;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>

<header>
    <h1>EBookHub</h1>
    <nav>
        <a href="home.php">Home</a>
        <a href="buy_sell.php">Buy/Sell</a>
        <a href="search.php">Search</a>
        <?php // if (!isset($_SESSION['user_id'])): ?>
            <a href="login.php">Login</a>
            <a href="signup.php">Sign Up</a>
        <?php // endif; ?>
    </nav>
</header>

<div class="bill-container">
    <?php if ($book): ?>
        <div class="bill-header">
            <h2><i class="fas fa-receipt"></i> Purchase Bill</h2>
        </div>
        <div class="success-msg">
            <i class="fas fa-check-circle"></i> Thank you for your purchase!
        </div>
        <div class="bill-detail">
            <p><strong>Book Title:</strong> <span><?= htmlspecialchars($book['title']) ?></span></p>
            <p><strong>Author:</strong> <span><?= htmlspecialchars($book['author']) ?></span></p>
            <p><strong>Condition:</strong> <span><?= htmlspecialchars($book['condition_status']) ?></span></p>
            <p class="price-row"><strong>Price Paid:</strong> <span>₹<?= htmlspecialchars(number_format($book['price'], 2)) ?></span></p>
            <p><strong>Purchase Date:</strong> <span><?= date("d M Y, h:i A") ?></span></p>
            <p><strong>Transaction ID:</strong> <span><?= uniqid('EB_') ?></span></p> </div>
        <div class="back-btn">
            <a href="buy_sell.php"><i class="fas fa-arrow-left"></i> Back to Buy/Sell</a>
        </div>
    <?php else: ?>
        <div class="bill-header">
            <h2><i class="fas fa-exclamation-triangle"></i> Book Not Found</h2>
        </div>
        <div class="not-found-msg">
            The requested book could not be found or the ID is invalid.
        </div>
        <div class="back-btn">
            <a href="buy_sell.php"><i class="fas fa-arrow-left"></i> Back to Buy/Sell</a>
        </div>
    <?php endif; ?>
</div>

</body>
</html>